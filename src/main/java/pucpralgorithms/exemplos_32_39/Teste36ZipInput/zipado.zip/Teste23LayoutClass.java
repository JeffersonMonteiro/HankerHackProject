//Exemplo que mostra como mudar o layout de um conteiner
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;


public class Teste23LayoutClass {

	public static void main(String[] args) {
		
		MyFrame janela = new MyFrame();
		janela.setTitle("teste de layout");
		janela.setSize(500,400);
		janela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		janela.setVisible(true);
		
	}
}

class MyFrame extends JFrame implements ActionListener
{
	private JButton a, b, c, d;
	BorderLayout bl;
	FlowLayout fl;
	GridLayout gl;
	MyFrame()
	{
		a = new JButton("FlowLayout");
		b = new JButton("BorderLayout");
		c = new JButton("GridLayout");
		bl = new BorderLayout();
		fl = new FlowLayout();
		gl = new GridLayout(2,2);
		
		getContentPane().setLayout(fl);
		getContentPane().add(a);
		getContentPane().add(b);
		getContentPane().add(c);
		
		
		a.addActionListener(this);
		b.addActionListener(this);
		c.addActionListener(this);
		
		
		
	}

	
	public void actionPerformed(ActionEvent arg0) {
		
		if((JButton)arg0.getSource()==a)
		{
			getContentPane().setLayout(fl);
			validate();
			
		
		}
		else if((JButton)arg0.getSource()==b)
		{
			getContentPane().setLayout(bl);
			getContentPane().remove(a);
			getContentPane().remove(b);
			getContentPane().remove(c);
			
			
			getContentPane().add(a, BorderLayout.NORTH);
			getContentPane().add(b, BorderLayout.CENTER);
			getContentPane().add(c, BorderLayout.SOUTH);
			validate();
			
			
		
		} 
		else if((JButton)arg0.getSource()==c)
		{
			getContentPane().setLayout(gl);
			validate();
		}
			
		
	}
	
}
