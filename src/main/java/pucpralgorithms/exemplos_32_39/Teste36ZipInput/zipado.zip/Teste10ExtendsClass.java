//Este exemplo mostra uma rela��o de heran�a entre a classe Gerente
//(subclasse) e a classe Empregado (superclasse)
public class Teste10ExtendsClass {

	public static void main(String[] args) {
		
		Empregado e1 = new Empregado("ciclano", 32);
		e1.setIdade(25);
		e1.calculaSalario(190);
		
		Gerente g1 = new Gerente("Fulano", 35, 0);
		
		Empregado e2 = new Gerente("Beltrano", 40, 0);
		
		
		//((Gerente)e2).setBonus(1000);
		
		
		
		g1.setNome("Beltrano");
		g1.setIdade(32);
		g1.calculaSalario(195);
		
		e1.mostraDados();
		g1.mostraDados();
		
	}
}

class Empregado
{
	String nome;
	int idade;
	double salario;
	
	public double getSalario() { return salario; }
	public int getIdade() { return idade; }
	public String getNome() { return nome; }
	public void calculaSalario(int horas) 
	{ 
		if (horas > 176)
		{
			salario = 176*10 + (horas - 176)*15;
		}
		else salario = horas*10; 
	}
	public void setIdade(int i) { idade = i; }
	public void setNome(String n) { nome = n; }
	public void mostraDados()
	{
		System.out.println("Nome do empregado: " + nome);
		System.out.println("Idade: " + idade);
		System.out.println("Sal�rio: " + salario);
		
	
	}
	public Empregado(String n, int id)
	{
		nome = n;
		idade = id;
		salario = 0;

	}
	
	
}


//Aqui especifica-se que a classe Gerente estende a classe Empregado
//Ou seja, torna-se subclasse da classe Empregado
class Gerente extends Empregado
{
	double bonus;
	void setBonus(double b) { bonus = b;}

	//calculaSalario() utiliza o valor do atributo 'salario', 
	//que foi herdado da classe Empregado. Como o atributo 'salario'
	//tem acesso default, pode ser acessado pela classe Gerente
	//que faz parte do mesmo pacote.
	//Caso se desejasse que 'salario' fosse inacess�vel para outras classes
	//do pacote e acess�vel somente para Gerente (ou outras derivadas), 
	//seria necess�rio especificar o seu acesso como 'protected'
	public void calculaSalario(int horas)
	{
		if (horas > 176)
		{
			salario = 176*20 + (horas - 176)*30;
		}
		else salario = horas*20; 
		salario += bonus;
	}
	
	
	//Redefini��o do m�todo mostraDados()
	public void mostraDados()
	{
		System.out.println("Nome do chefe: " + nome);
		System.out.println("Idade: " + idade);
		System.out.println("Sal�rio: " + salario);
	
	}
	
	public Gerente(String n, int id, double b)
	{
		super(n, id);
		bonus = b;
		
	}
	
	
	
}
